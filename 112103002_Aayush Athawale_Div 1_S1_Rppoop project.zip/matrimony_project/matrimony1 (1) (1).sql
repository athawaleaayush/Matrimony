-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2023 at 07:16 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `matrimony1`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2021_10_22_181652_create_customers_table', 2),
(6, '2021_10_26_173145_create_partnerprefs_table', 3),
(7, '2021_10_26_175623_create_photos_table', 4),
(8, '2021_10_27_170955_create_admins_table', 5),
(9, '2016_06_01_000001_create_oauth_auth_codes_table', 6),
(10, '2016_06_01_000002_create_oauth_access_tokens_table', 6),
(11, '2016_06_01_000003_create_oauth_refresh_tokens_table', 6),
(12, '2016_06_01_000004_create_oauth_clients_table', 6),
(13, '2016_06_01_000005_create_oauth_personal_access_clients_table', 6),
(14, '2022_01_17_182002_create_customers_table', 7),
(15, '2022_01_20_173000_create_relation_managers_table', 8),
(16, '2022_01_25_184102_create_users_table', 9),
(17, '2022_01_25_190812_create_users_table', 10),
(18, '2022_03_19_100048_create_express_intrests_table', 11),
(19, '2022_05_01_094145_create_payments_table', 12),
(20, '2022_06_24_010902_create_contacts_table', 13),
(21, '2022_07_23_190345_create_leads_lable', 14),
(22, '2022_12_25_172533_create_countries_states_cities_tables', 15),
(23, '2023_02_25_041828_create_religion_table', 16),
(24, '2023_02_25_045908_create_religions_table', 17),
(25, '2023_02_25_051553_create_religions_table', 18),
(26, '2023_02_25_113852_create_casts_table', 19),
(27, '2023_02_28_173202_create_gender_table', 20),
(28, '2023_03_03_181042_create_genders_table', 21),
(29, '2023_03_03_233519_create_profile_created_bys_table', 22),
(30, '2023_03_03_235015_create_employeds_table', 23),
(31, '2023_03_04_000011_create_maritalstatuss_table', 24),
(32, '2023_03_04_000814_create_habits_table', 25),
(33, '2023_03_04_004124_create_hights_table', 26),
(34, '2023_03_04_005736_create_educations_table', 27),
(35, '2023_03_04_011225_create_occupations_table', 28),
(36, '2023_03_04_014447_create_physical_statuses_table', 29),
(37, '2023_03_04_060134_create_complexions_tables', 30),
(38, '2023_03_04_060134_create_complexions', 31),
(39, '2023_03_05_053811_create_rashi_table', 32),
(40, '2023_03_05_030453_create_body_types_table', 33);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `scopes` text DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_access_tokens`
--

INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('014c49aa3ad0b2eeecca91f9140813b965103c9a150efdf5156f38fa8da9900fb3fb6fc1bd76fd35', 17, 1, 'Access Token', '[]', 0, '2022-01-08 13:42:17', '2022-01-08 13:42:17', '2023-01-08 19:12:17'),
('05a738bf6875919e85fd81d46410e05ea5321d92c0662891ab712a9b2205d6357694473fbeac2e99', 17, 1, 'Access Token', '[]', 0, '2022-01-08 13:42:29', '2022-01-08 13:42:29', '2023-01-08 19:12:29'),
('1bfd5d3ed6b84e74a8e21696eb01eaf7eb63d340220c6b243557a937b8be1da07b80a5c6e621229a', 17, 1, 'Access Token', '[]', 0, '2022-01-08 13:42:22', '2022-01-08 13:42:22', '2023-01-08 19:12:22'),
('1e2e07b84f1722481d013421901a2303d75aaa6444c725e95782c7498d1dbfe22761ff28526ea1ad', 17, 1, 'Access Token', '[]', 0, '2022-01-08 13:41:55', '2022-01-08 13:41:55', '2023-01-08 19:11:55'),
('40d3ee75a518f36db69e1b41e94a2c56f57d71263c38c468ef99c912a0f9adba162510cabdb5f9cf', 17, 1, 'Access Token', '[]', 0, '2022-01-08 13:42:36', '2022-01-08 13:42:36', '2023-01-08 19:12:36'),
('640d26a1e74bf3d91eb9bb8076bea7763ffda078dc37217f194443cab8fcec8621123c15c24e5957', 17, 1, 'Access Token', '[]', 0, '2022-01-08 13:42:52', '2022-01-08 13:42:52', '2023-01-08 19:12:52'),
('7f6bdd7686def93c883c5b2dab769ee3668a83fd525e312d82518c6685abc1c0c629a00664e709eb', 17, 1, 'Access Token', '[]', 0, '2022-01-08 13:42:45', '2022-01-08 13:42:45', '2023-01-08 19:12:45'),
('a62e8ad3385db454ac16ac074afb37bc390acdb2501a7ab0996055a3ae7cf8e0684d7db4a329efd8', 17, 1, 'Access Token', '[]', 0, '2022-01-08 13:37:21', '2022-01-08 13:37:21', '2023-01-08 19:07:21'),
('c3d8f90c76eedf8d5483c018ec524f41f948cdb87be6cf0569392dc58a66aff624242e17516d47bd', 17, 1, 'Access Token', '[]', 0, '2022-01-08 13:42:42', '2022-01-08 13:42:42', '2023-01-08 19:12:42'),
('d9e35801798e5a9c24222d94addc5a2b636330856f3443d11e3fd15482c5248a6b3a015e694b0655', 17, 1, 'Access Token', '[]', 0, '2022-01-08 13:42:33', '2022-01-08 13:42:33', '2023-01-08 19:12:33'),
('dc1d25325f50adb516b1f7ebfebc1439c1311347cea626585788e69bd2ab2394eada8bca38e9381e', 17, 1, 'Access Token', '[]', 0, '2022-01-08 13:42:26', '2022-01-08 13:42:26', '2023-01-08 19:12:26'),
('f2b47a96829566266415061cbbfce64ef996777e17eb64a867b5cc4eb2854d5ee04d2356f684fe40', 17, 1, 'Access Token', '[]', 0, '2022-01-08 13:42:49', '2022-01-08 13:42:49', '2023-01-08 19:12:49'),
('f4204e90c707a586f29164a84bd1135af435768cb74a669dab29e920d26af28db2c4fe4c78fe2209', 17, 1, 'Access Token', '[]', 0, '2022-01-08 13:42:55', '2022-01-08 13:42:55', '2023-01-08 19:12:55'),
('f4c29c9c7cea1da7eb51ee07ca132682285385e7579e9f5490ec2c56599ed31f9b0ea8f110c9fb5f', 17, 1, 'Access Token', '[]', 0, '2022-01-08 13:42:39', '2022-01-08 13:42:39', '2023-01-08 19:12:39'),
('fb13aec4adfcb057dbcabc6b545c66e66ad208197526f0d79b5343563448d24d0618f1cb49e97215', 17, 1, 'Access Token', '[]', 0, '2022-01-08 13:42:59', '2022-01-08 13:42:59', '2023-01-08 19:12:59'),
('fc3a43c5d7930452cd7a1aa15e29bb4f0067bcdd122adeba30a2c3ae59bb25183391c035df840ffa', 17, 1, 'Access Token', '[]', 0, '2022-01-08 13:44:53', '2022-01-08 13:44:53', '2023-01-08 19:14:53');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `scopes` text DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `secret` varchar(100) DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `redirect` text NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `provider`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Laravel Personal Access Client', '36QPkFc1lI4BX6LwElUCHuJYst1f5mXoaehamYiT', NULL, 'http://localhost', 1, 0, 0, '2021-12-11 05:49:09', '2021-12-11 05:49:09'),
(2, NULL, 'Laravel Password Grant Client', '3e9K4dmHtIbyIMEVQHxgHc7ZpEmr76VGQ7DQlXch', 'users', 'http://localhost', 0, 1, 0, '2021-12-11 05:49:09', '2021-12-11 05:49:09');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_personal_access_clients`
--

INSERT INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2021-12-11 05:49:09', '2021-12-11 05:49:09');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) NOT NULL,
  `access_token_id` varchar(100) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `dateofbirth` date DEFAULT NULL,
  `gender` int(2) DEFAULT 0,
  `userlevel` int(11) DEFAULT NULL,
  `plan` enum('F','S','G','D') NOT NULL DEFAULT 'F',
  `token` varchar(250) DEFAULT NULL,
  `is_verified` tinyint(4) NOT NULL DEFAULT 0,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `contact_number` varchar(20) NOT NULL,
  `hobby` varchar(250) NOT NULL,
  `education` varchar(250) NOT NULL,
  `occupation` varchar(250) NOT NULL,
  `annual_income` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `email_verified_at`, `password`, `dateofbirth`, `gender`, `userlevel`, `plan`, `token`, `is_verified`, `remember_token`, `created_at`, `updated_at`, `first_name`, `middle_name`, `last_name`, `contact_number`, `hobby`, `education`, `occupation`, `annual_income`) VALUES
(331, 'Ayush', 'athawaleaayush@gmail.com', NULL, '$2y$10$O9DExoTOQdYJ2MT2D/TdYOj0fBax.4tQgddaeQlWdM.sInZw89.62', '2000-02-02', 1, NULL, 'F', 'bCHp5IDNWyVn4WIK8bnCDkACil37PLeyP8ZRL4SlKqlaYip4CVeBdEENjnE6', 0, NULL, '2023-06-08 12:54:16', '2023-06-08 12:54:16', 'Ayush', 's', 'Athawale', '9858789958', '', '', '', ''),
(332, 'Archana', 'archanasingh@gmail.com', NULL, '$2y$10$bUjYYDIWSVx2ZUmDLgYcmeBZWoYkFKc5HzLnlflrawP8S18f.56am', '1997-06-07', 2, NULL, 'F', 'utqUIRZXzeUhJndbVd4FTRLkzBgfzMVQ7jMzcd8HGwzNpAFw8ahKO00AInua', 0, NULL, '2023-06-08 20:51:19', '2023-06-08 20:51:19', 'Archana', 'Mohan', 'Singh', '9585898589', 'Singing,Dancing', 'CA from Sagar University', 'Bank Manager', '10,00000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_auth_codes_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=333;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
